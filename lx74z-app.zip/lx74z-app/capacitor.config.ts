import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.lx74z.messenger',
  appName: 'Lx74z',
  webDir: 'www',
  server: {
    androidScheme: 'https'
  },
  android: {
    backgroundColor: '#0a001a',
    allowMixedContent: false
  }
};

export default config;
